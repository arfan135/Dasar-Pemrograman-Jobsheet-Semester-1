public class MyFirstJava {
	
	 public static void main(String[] args) {
		 
		System.out.println ("|----------------------------------------------|") ;
		System.out.println ("|BIODATA MAHASISWA JURUSAN TEKNOLOGI INFORMASI |");
		System.out.println ("|----------------------------------------------|") ;
		System.out.println ("|NAMA            :ARFAN ROMADHANI              |") ;
		System.out.println ("|NIM             :2231750010                   |");
		System.out.println ("|ALAMAT          :JL.BRAWIJAYA NO.13 PAMEKASAN |"); 
		System.out.println ("|NO.HP           :085257722817                 |");
		System.out.println ("|HOBI            :OLAHRAGA                     |");
		System.out.println ("|----------------------------------------------|") ;
		
		 
}
}        