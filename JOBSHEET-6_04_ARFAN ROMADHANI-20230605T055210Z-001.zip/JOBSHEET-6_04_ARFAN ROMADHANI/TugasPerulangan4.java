import java.util.Scanner;

public class TugasPerulangan4 {
	public static void main(String[] args){

		int a=0, nim=10+2, x;
		Scanner scan = new Scanner(System.in);

		System.out.print("Masukkan batas angka: ");
		x = scan.nextInt();

		while (true){
			a++;
			if (a>x){
				break;
			}
			else if (a%nim==0){
				continue;
			}
			System.out.print(a +" ");
		}
	}
}