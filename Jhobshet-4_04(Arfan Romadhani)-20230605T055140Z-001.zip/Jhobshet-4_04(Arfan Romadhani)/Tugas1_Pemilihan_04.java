import java.util.Scanner;
public class Tugas1_Pemilihan_04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x, y;

        System.out.print("Masukkan bilangan pertama : ");
        x = input.nextInt();
        System.out.print("\nMasukkan bilangan kedua : ");
        y = input.nextInt();
        if (x > y) {
            
            System.out.println("Bilangan terbesar = " + x + ", bilangan terkecil = " + y);
        }
        else {
            System.out.println("Bilangan terbesar = " + y + ", bilangan terkecil = " + x);
        }
    }
}