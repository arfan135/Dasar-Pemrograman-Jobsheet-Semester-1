import java.util.Scanner;
public class Greeting_04 {
    static void beriSalam(){
        System.out.println("Halo Selamat Pagi");
    }
    public static void main(String[] args){
        beriSalam();
    }
}