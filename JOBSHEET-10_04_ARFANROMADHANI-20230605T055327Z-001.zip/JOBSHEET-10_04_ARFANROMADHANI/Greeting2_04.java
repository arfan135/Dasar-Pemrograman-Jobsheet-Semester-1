import java.util.Scanner;
public class Greeting2_04 {
    static void beriSalam(){
        System.out.println("Halo! Selamat Pagi");
    }
    static void beriUcapan(String ucapan){
        System.out.println(ucapan);
    }
    public static void main(String[] args){
        beriSalam();
    }
}