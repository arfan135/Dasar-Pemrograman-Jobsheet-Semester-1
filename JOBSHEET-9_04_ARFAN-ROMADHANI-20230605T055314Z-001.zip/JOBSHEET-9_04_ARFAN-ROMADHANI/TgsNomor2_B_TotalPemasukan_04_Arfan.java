import java.util.Scanner;
public class TgsNomor2_B_TotalPemasukan_04_Arfan{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int b, k;
        int tlogamas[][] = new int[3][4];
        String jenisBuku[] = { "Novel", "Komik", "Buku Pelajaran", "Ensiklopedia" };
        int total[] = new int[5];
        int pemasukanTotal, pemasukanNovel, pemasukanKomik, pemasukanBupel, pemasukanEnsi, totalSemua = 0;
        String cabang[] = new String[3];
        for (b = 0; b < tlogamas.length; b++){
            System.out.print("Masukkan lokasi cabang : ");
            cabang[b] = sc.next();

            for (k = 0; k < tlogamas[0].length; k++){
                System.out.print("Masukkan jumlah " + (jenisBuku[k]) + " : ");
                tlogamas[b][k] = sc.nextInt();
            }
            pemasukanNovel = tlogamas[b][0] * 40000;
            pemasukanKomik = tlogamas[b][1] * 28000;
            pemasukanBupel = tlogamas[b][2] * 60000;
            pemasukanEnsi = tlogamas[b][3] * 75000;
            pemasukanTotal = pemasukanNovel + pemasukanKomik + pemasukanBupel + pemasukanEnsi;
            total[k] = pemasukanTotal;
            System.out.println("Total pemasukan cabang " + cabang[b] + " = Rp." + (pemasukanTotal));
            totalSemua += total[k];
        }
        System.out.println("Total pemasukan semua cabang = Rp."+totalSemua);
    }
}