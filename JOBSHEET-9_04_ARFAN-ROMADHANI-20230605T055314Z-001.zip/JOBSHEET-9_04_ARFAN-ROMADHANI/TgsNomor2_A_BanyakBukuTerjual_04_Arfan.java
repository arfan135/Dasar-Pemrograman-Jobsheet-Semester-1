import java.util.Scanner;
public class TgsNomor2_A_BanyakBukuTerjual_04_Arfan{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int b, k;
        int total[] = new int[4];
        int pertama, kedua, ketiga, keempat;
        int togamas[][] = new int[3][4];
        String jenisBuku[] = { "novel", "komik", "buku pelajaran", "ensiklopedia", };
        String cabang;

        for (b = 0; b < togamas.length; b++){
            System.out.print("Masukkan lokasi cabang : ");
            cabang = sc.next();
            for (k = 0; k < togamas[0].length; k++){
                System.out.print("Masukkan jumlah " + (jenisBuku[k]) + " : ");
                togamas[b][k] = sc.nextInt();
            }
            pertama = togamas[b][0];
            kedua = togamas[b][1];
            ketiga = togamas[b][2];
            keempat = togamas[b][3];
            int jumlah = pertama + kedua + ketiga + keempat;
            total[b] = jumlah;
            System.out.println("Total Buku yang terjual : " + jumlah);
            System.out.println("------------------------------------------------");
        }
    }
}