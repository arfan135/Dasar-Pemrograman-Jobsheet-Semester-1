import java.util.Scanner;
public class TgsNomor1_04_ArfanRomadhani{
    public static void main(String[] args){
        char karakter[] = { 'A', 'R', 'F', 'A','N',
        'R', 'O', 'M', 'A', 'D', 'H', 'A', 'N', 'I' };
    char nama[][] = new char[8][5];
    int i, j;
    int p=0;
    for (i = 0; i < nama.length; i++) {
        for (j = 0;  j < nama[0].length; j++) {
            if(p==karakter.length){
                p=0;
            }
                nama[i][j] = karakter[p];
                p++;
                System.out.print(nama[i][j] + " ");
                }
                System.out.println();
    }
    }
}