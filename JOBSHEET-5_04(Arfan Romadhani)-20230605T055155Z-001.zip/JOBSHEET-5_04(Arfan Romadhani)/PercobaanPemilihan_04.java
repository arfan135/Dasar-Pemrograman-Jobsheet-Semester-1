import java.util.Scanner;
public class PercobaanPemilihan_04 {
    public static void main(String [] args){
        int total, diskon, bayar;
        String kartu;
        Scanner sc = new Scanner(System.in);

       System.out.println("Apakah pelanggan memiliki kartu anggota  (y atau t)?");
       kartu = sc.nextLine();
       
       System.out.println("Berapa total harga belanjaan? Rp");
       total = sc.nextInt();

       if(kartu.equals("y")){
        if(total > 500_000){
            diskon = 50_000;
        }else{
            diskon = 25_000;
        }
       } else {
        if(total > 200_000){
            diskon = 10000;
        } else {
            diskon = 0;
        }
       }

       bayar = total - diskon;
       System.out.println("Total yang harus di bayar: Rp" + bayar);
    } 
}